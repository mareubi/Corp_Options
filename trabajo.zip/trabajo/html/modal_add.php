<div id="addProductModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form name="add_product" id="add_product">
					<div class="modal-header">						
						<h4 class="modal-title">Agregar Producto</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						<div class="form-group">
							<label>Código</label>
							<input type="text" name="code"  id="code" class="form-control" required>
							
						</div>
						<div class="form-group">
							<label>Hardware</label>
							<br>
							<select name="hardware">
								<option>Seleccionar</option>
  								<option value="1">Ped-1</option>
  								<option value="2">Ped-2</option>
  								<option value="3">Ped-3</option>
  								<option value="4">Receptor-1</option>
  								<option value="5">Receptor-2</option>
							</select>
						</div>
						<div class="form-group">
							<label>Cliente Corporativo</label>
							<input type="text" name="category" id="category" class="form-control" required>
						</div>			
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-success" value="Guardar datos">
					</div>
				</form>
			</div>
		</div>
	</div>